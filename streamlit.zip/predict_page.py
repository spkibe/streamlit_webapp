import pickle
import numpy as np
import streamlit as st

def show_predict_page():
    st.title("Heart Disease Prediction")

    st.write("""### Input patient's data to predict heart disease""")
